# PotatoAuth — Fabric 26.2 starter

This is a **source project**, not a finished `.jar`. It registers a Right Shift keybind and displays a small confirmation message. It does not bypass online-mode authentication.

## Build requirements
- Minecraft 26.2
- Java 25 JDK
- Gradle 9.5.1
- Fabric Loader 0.19.3
- Fabric API 0.161.0+26.2
- Fabric Loom 1.17

## Build
Open this folder in a Gradle-capable IDE or run `gradle build` with Gradle 9.5.1 and Java 25. The output jar should appear in `build/libs/`.

## Install
Copy the built `potatoauth-0.1.0.jar` into the `mods` folder of your **Fabric 26.2** game instance. Install the matching Fabric API too.

## Current scope
- Right Shift keybind is registered.
- A starter client message confirms the keybind fired.
- No password collection, token extraction, session spoofing, or authentication bypass.

## Next development step
Replace the confirmation message with a proper client screen, then add safe account-provider handoff using official Microsoft authentication flows. Never paste Microsoft passwords or access tokens into third-party forms.
